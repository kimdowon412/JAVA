package views;

import game.MainGame;
import javafx.fxml.FXML;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.KeyEvent;

public class Maincontroller {
	@FXML
	private Canvas canvas;
		
	private GraphicsContext gc;
	
	private MainGame game;
	
	@FXML
	private void initialize() {
		gc = canvas.getGraphicsContext2D();
		game = new MainGame(canvas);
		game.gameStart();
	}
	
	public void keyPressHandle(KeyEvent e) {
		game.keyPressHandle(e);
	}
	public void keyUpHandle(KeyEvent e) {
		game.keyUpHandle(e);
	}
}
